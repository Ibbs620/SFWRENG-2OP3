/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
 *
 * Write a subroutine, user input an 1D array of integers and an integer target,
 * return indices of the two numbers such that they add up to target.
 *
 * INPUT: user input array and target
 * OUTPUT: the indices of the two numbers such that they add up to target.
 *
 * The array and target are parameters to the subroutine.
 * User can get hint to input array and target number, respectively.
 *
 * Keep the input format in the example and make your code user-friendly.
 *
 * Example:
 * INPUT: [2,7,11,15], 9
 * OUTPUT: [0,1]
 *
 */

import java.util.Scanner;

public class Q1_TwoSum {
    /* place your subroutine code here */
    public static int[] findTargetSum(int[] array, int target){
        for(int i = 0; i < array.length; i++){
            for(int j = 0; j < array.length; j++){
                if(i == j) continue;
                int sum = array[i] + array[j];
                if(sum == target) {
                    int[] result = {i, j};
                    return result;
                }
            }
        }
        int[] noIndicesFound = {-1, -1};
        return noIndicesFound;
    }


    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter array contents seperated by space (e.g. 1 2 3): ");
        String arrayString = scanner.nextLine();
        String stringArray[] = arrayString.split(" ");
        int[] array = new int[stringArray.length];
        for(int i = 0; i < array.length; i++){
            array[i] = Integer.parseInt(stringArray[i]);
        }
        System.out.print("Enter target: ");
        int target = scanner.nextInt();
        int[] indices = findTargetSum(array, target);
        if(indices[0] == -1) {
            System.out.println("No indices found");
        } else {
            System.out.println("Indices that sum up to target: " + indices[0] + " " + indices[1]);
        }
    }
}
