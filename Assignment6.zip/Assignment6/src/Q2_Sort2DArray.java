/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
 *
 * Write a java program, use "subroutine" to finish sorting a 2-dimension array.
 *
 * User input a 2-dimension array of double type, return it in non-decreasing
 * order according to values in the first raw, if there are two or more same
 * element in the first raw, keep the original sequence.
 *
 * INPUT: a user input 2-dimension array.
 * OUTPUT: sorted input array in non-decreasing order according to values in the first raw.
 *
 * Note: considering how to take users' input, you can set some rules (give users some hints)
 * to make your code user-friendly.
 * User will follow your instruction to input test example.
 *
 * Example 1
 * INPUT: if user input array (Order 2*4) is
 *        1.45  0.25  8.95  0.99
 *        2.56  5.67  0.47  2.65
 *
 * OUTPUT: 0.25  0.99  1.45  8.95
 *         5.67  2.65  2.56  0.47
 *
 * Example 2
 * INPUT: if user input array (Order 5*5) is
 *        0.95  0.23  0.95  0.95  0.65
 *        2.56  5.67  0.47  2.65  0.47
 *        1.45  0.25  8.95  0.99  0.67
 *        5.67  2.65  0.25  8.95  0.99
 *        1.23  4.21  0.97  7.64  8.52
 *
 * OUTPUT: 0.23  0.65  0.95  0.95  0.95
 *         5.67  0.47  2.56  0.47  2.65
 *         0.25  0.67  1.45  8.95  0.99
 *         2.65  0.99  5.67  0.25  8.95
 *         4.21  8.52  1.23  0.97  7.64
 *
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Q2_Sort2DArray {
    /* place your subroutine code here */
    public static ArrayList<double[]> sortFirstRow(ArrayList<double[]> array){
        int width = array.get(0).length;
        int length = array.size();
        for(int i = 0; i < width ; i++){
            int mindex = i;
            for(int j = i; j < width; j++){
                if(array.get(0)[j] < array.get(0)[mindex]){
                    mindex = j;
                }
            }
            for(int j = 0; j < length; j++){
                double temp = array.get(j)[mindex];
                array.get(j)[mindex] = array.get(j)[i];
                array.get(j)[i] = temp;
            }
        }
        return array;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        System.out.println("Enter a 2D array of doubles. Press enter once to start a new row and twice to stop.");
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> arrayStrings = new ArrayList<>();
        ArrayList<double[]> doubleList = new ArrayList<>();
        while (true) {
            arrayStrings.add(scanner.nextLine());
            if(arrayStrings.contains("")) break;
            String[] stringArray = arrayStrings.get(arrayStrings.size() - 1).split(" ");
            double[] row = new double[stringArray.length];
            for (int i = 0; i < stringArray.length; i++) {
                row[i] = Double.parseDouble(stringArray[i]);
            }
            doubleList.add(row);
        }

        ArrayList<double[]> sortedList = sortFirstRow(doubleList);
        System.out.println("Sorted array: ");
        for (double[] i : doubleList) {
            for (double j : i){
                System.out.print(j);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}
