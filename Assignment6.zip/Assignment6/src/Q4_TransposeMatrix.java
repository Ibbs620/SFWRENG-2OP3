/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 4 (20 marks)
 *
 * Write a java program to compute the transpose of a user input matrix,
 * whose elements are all integers.
 *
 * Converting rows of a matrix into columns and columns of a matrix into
 * row is called transpose of a matrix.
 *
 * INPUT: user input matrix (2D array).
 * OUTPUT: the transpose of input matrix.
 *
 * Note: considering how to take users' input, you can set some rules
 * (give users some hints) to make your code user-friendly.
 * User will follow your instruction to input test example.
 *
 * Example:
 * INPUT: 4  6  8
 *        5  8  9
 *        2  1  8
 *
 * OUTPUT: 4  5  2
 *         6  8  1
 *         8  9  8
 *
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Q4_TransposeMatrix {
    /* place your subroutine code here */
    public static ArrayList<int[]> transpose(ArrayList<int[]> array){
        ArrayList<int[]> result = new ArrayList<>();
        for (int i = 0; i < array.get(0).length; i++){
            result.add(new int[array.size()]);
        }
        for (int i = 0; i < array.size(); i++) {
            for(int j = 0; j < array.get(i).length; j++){
                result.get(j)[i] = array.get(i)[j];
            }
        }
        return result;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        System.out.println("Enter a 2D array of integers. Press enter once to start a new row and twice to stop.");
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> arrayStrings = new ArrayList<>();
        ArrayList<int[]> intList = new ArrayList<>();
        while (true) {
            arrayStrings.add(scanner.nextLine());
            if(arrayStrings.contains("")) break;
            String[] stringArray = arrayStrings.get(arrayStrings.size() - 1).split(" ");
            int[] row = new int[stringArray.length];
            for (int i = 0; i < stringArray.length; i++) {
                row[i] = Integer.parseInt(stringArray[i]);
            }
            intList.add(row);
        }
        ArrayList<int[]> transposed = transpose(intList);
        System.out.println("Transposed array: ");
        for (int[] i : transposed) {
            for (int j : i){
                System.out.print(j);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}
