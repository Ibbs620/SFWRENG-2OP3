/* Assignment 5 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
 *
 * Write a Java program, use 'subroutine' to finds the minimum value of
 * the first N elements of an array of type int.
 * Meanwhile, your code can throw an IllegalException (custom run-time
 * exception, which can be one provided by Java) if N is not in the range
 * of the length of input array.
 *
 * Input: user input array and number N.
 * Output: the minimum value of the first N elements of the array.
 *
 * Note: The array and N are parameters to the subroutine.
 * Users will input an array with no specific length.
 *
 */

import java.util.Scanner;

public class Q1_FindMinimum {
    /* place your subroutine code here */
    public static int minimum(int[] array, int n){
        if(n > array.length){
            throw new IllegalArgumentException();
        }
        int min_val = array[0];
        for(int i = 1; i < n; i++){
            if(min_val > array[i]){
                min_val = array[i];
            }
        }
        return min_val;
    }

    public static void main(String[] args) {
        int n;
        int int_array[];
        String int_string;
        String[] string_array;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a list of integers seperated by a space (e.g 1 2 3 4): ");
        int_string = scanner.nextLine();
        System.out.print("Enter n: ");
        n = scanner.nextInt();

        string_array = int_string.split(" ");
        int_array = new int[string_array.length];
        for(int i = 0; i < string_array.length; i++){
            int_array[i] = Integer.parseInt(string_array[i]);
        }
        System.out.println("Minimum value of first " + n + " integers is " + minimum(int_array, n));
    }
}


