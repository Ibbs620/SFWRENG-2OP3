/* Assignment 4 (100 marks in total; 5% of the final score of this course)
 *
 * Question 3 (30 marks)

Many companies use telephone numbers like 555-GET-Food so the number is easier for their customers to remember.
On a standard telephone, the alphabetic letters are mapped to numbers in the following fashion:

A, B, and C = 2
D, E, and F = 3
G, H, and I = 4
J, K, and L = 5
M, N, and O = 6
P, Q, R, and S = 7
T, U, and V = 8
W, X, y, and Z = 9
Write an application that asks the user to enter a 10-character telephone number in the format XXX-XXX-XXXX.
The application should display the telephone number with any alphabetic characters that appeared in the original
translated to their numeric equivalent.

Example: if the user enters 555GETFOOD the application should display 555-438-3663.
*

 */

import java.util.Scanner;

public class Q3_AlphabeticPhoneNumber
{
    private static Scanner input;

    public static void main(String[] args)
    {
        input = new Scanner(System.in);
        System.out.println("Enter The Phone Number (With Letters): ");
        String initial_phone_number = input.nextLine();

        initial_phone_number = initial_phone_number.toUpperCase();
        long phone_number_final = full_number(initial_phone_number);

        System.out.printf("%nOutput phone number for '%s' is '%s'",
                initial_phone_number, phone_number_final);
    }

    public static long full_number(String initial_phone_number)
    {
        // Use long instead of int for 'number' if the string will be longer than max int value
        // 2147483647, which is '10 digits'
        long number = 0; // 'number' is the digital phone number to compute from the initial alphabetic phone number.



        /* place your code here */

        String new_phone_number = "";
        for(int i = 0; i < initial_phone_number.length(); i++){
            if(initial_phone_number.charAt(i) == '-'){
                continue;
            }
            char character = initial_phone_number.charAt(i);
            switch (character){
                case 'A':
                case 'B':
                case 'C':
                    character = '2';
                    break;
                case 'D':
                case 'E':
                case 'F':
                    character = '3';
                    break;
                case 'G':
                case 'H':
                case 'I':
                    character = '4';
                    break;
                case 'J':
                case 'K':
                case 'L':
                    character = '5';
                    break;
                case 'M':
                case 'N':
                case 'O':
                    character = '6';
                    break;
                case 'P':
                case 'Q':
                case 'R':
                case 'S':
                    character = '7';
                    break;
                case 'T':
                case 'U':
                case 'V':
                    character = '8';
                    break;
                case 'W':
                case 'X':
                case 'Y':
                case 'Z':
                    character = '9';
                    break;
            }
            new_phone_number += character;
        }
        number = Long.parseLong(new_phone_number);

        // Return actual number only at the end of the function
        return number;

    }// End of full_number function
}
