/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 5 (20 marks)
 * 
 * Write a Java program to display the following pattern.
 * 
 * INPUT: n/a
 * OUTPUT: the following pattern of JAVA.
 
 
	   J    a   v     v  a                                                  
	   J   a a   v   v  a a                                                 
	J  J  aaaaa   V V  aaaaa                                                
	 JJ  a     a   V  a     a
 
 */

public class Q5_PrintPattern {
	public static void main(String[] args) {
        System.out.println("   J    a   v     v  a    ");
        System.out.println("   J   a a   v   v  a a   ");
        System.out.println("J  J  aaaaa   V V  aaaaa  ");
        System.out.println(" JJ  a     a   V  a     a");
    }
}
