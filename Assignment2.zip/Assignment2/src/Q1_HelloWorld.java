/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 1 (20 marks)
 * 
 * Write some code to implement the following class.
 * The goal is to print exactly the sentence: "Hello Java World!"
 * 
 * INPUT: n/a
 * OUTPUT: "Hello Java World!"
 */

public class Q1_HelloWorld {
    public static void main(String[] args){
        System.out.println("Hello Java World");
    }
}
