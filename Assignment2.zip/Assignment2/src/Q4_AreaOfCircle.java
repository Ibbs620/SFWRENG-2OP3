/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 4 (20 marks)
 * 
 * Write a Java program to print the area and perimeter of a circle.
 * 
 * INPUT: radius input by a user.
 * OUTPUT: the area and the perimeter of the circle defined by the radius. All results must use two significant digits after decimal point.
 * 
 * Hint: you may use java.util.Scanner to take user input real valued radius.
 * 
 */

import java.util.Scanner;

public class Q4_AreaOfCircle {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter radius: ");
		double radius = scanner.nextDouble();
		double area = radius * radius * Math.PI;
		double perimeter = radius * 2 * Math.PI;
		System.out.printf("Area: %.2f\n", area);
		System.out.printf("Perimeter: %.2f", perimeter);
	}
}
